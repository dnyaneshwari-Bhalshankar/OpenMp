#include<stdio.h>
#include<omp.h>

int main()
{
   int x=2;
    printf("Thread %d : value of  x before parallel region =%d, address = %p \n",omp_get_thread_num(),x, printf("Thread %d : value of  x before parallel region =%d, address = %p \n",omp_get_thread_num(),x,&x);&x);
#pragma omp parallel private(x)
   {
       printf("value of x inside parallel region =%d\n ",x);
      	   x= omp_get_thread_num();
     printf("Thread %d has private x= %d \n",omp_get_thread_num(),x);
      printf("address of x inside =%p\n",&x);

   }

    printf("value of x outside parallel region = %d",x);
 printf("address of x out side parallel=%p\n",&x);


}
